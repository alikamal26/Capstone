# The goal of this project are:
Travel App where client enters destination location and time of travel and the App displays the weather forcast as well as image of the location

## Build Tools
Setting up Webpack
Sass styles
Webpack Loaders and Plugins
Service workers
Retrieving data from external APIs

## Steps for starting the project:-
1- "npm install" making sure you are in the right directory
2- "npm run start" => to start API server
3- "npm run build-dev" => executing the client
4- "npm run build-prod" => executing the client
5- "npm run test" => for testing